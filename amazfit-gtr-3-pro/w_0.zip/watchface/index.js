﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let editableTimePointers_cover_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 454,
              // h: 454,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'tlo_Bi1.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'tlo_Bi2.png' },
              ],
              count: 2,
              default_id: 1,
              fg: 'tlo_Fi.png',
              tips_bg: 'tooltip.png',
              tips_x: 153,
              tips_y: 201,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 4,
              anim_size: 9,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 210,
              y: 300,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "star",
              anim_fps: 3,
              anim_size: 5,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'zn_error.png',
              second_centerX: 0,
              second_centerY: 0,
              second_posX: 0,
              second_posY: 0,
              second_cover_path: 'pola_Dmt_VBH.png',
              second_cover_x: 19,
              second_cover_y: 19,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 76,
              y: 310,
              week_en: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_tc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              week_sc: ["dt_1.png","dt_2.png","dt_3.png","dt_4.png","dt_5.png","dt_6.png","dt_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -111,
              day_startY: 314,
              day_sc_array: ["cyf_bs_00.png","cyf_bs_01.png","cyf_bs_02.png","cyf_bs_03.png","cyf_bs_04.png","cyf_bs_05.png","cyf_bs_06.png","cyf_bs_07.png","cyf_bs_08.png","cyf_bs_09.png"],
              day_tc_array: ["cyf_bs_00.png","cyf_bs_01.png","cyf_bs_02.png","cyf_bs_03.png","cyf_bs_04.png","cyf_bs_05.png","cyf_bs_06.png","cyf_bs_07.png","cyf_bs_08.png","cyf_bs_09.png"],
              day_en_array: ["cyf_bs_00.png","cyf_bs_01.png","cyf_bs_02.png","cyf_bs_03.png","cyf_bs_04.png","cyf_bs_05.png","cyf_bs_06.png","cyf_bs_07.png","cyf_bs_08.png","cyf_bs_09.png"],
              day_zero: 1,
              day_space: -16,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 309,
              image_array: ["s00.png","s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 94,
              y: 80,
              src: 'brak_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 334,
              y: 80,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'cyferblat_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 309,
              image_array: ["s00.png","s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 45,
              y: 151,
              w: 130,
              h: 55,
              select_image: 'ram_SZB.png',
              un_select_image: 'ram_UZB.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
              ],
              count: 6,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tooltip.png',
              tips_x: -8,
              tips_y: 61,
              tips_width: 155,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 65,
                  y: 150,
                  image_array: ["luk_L.png"],
                  image_length: 1,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 69,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_proc.png',
                  unit_tc: 'cyf_par_proc.png',
                  unit_en: 'cyf_par_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 128,
                  y: 175,
                  src: 'iko_AKU.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 60,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_but.png',
                  unit_tc: 'cyf_par_but.png',
                  unit_en: 'cyf_par_but.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 65,
                  y: 150,
                  src: 'luk_L.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 69,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 4,
                  unit_sc: 'cyf_par_cal.png',
                  unit_tc: 'cyf_par_cal.png',
                  unit_en: 'cyf_par_cal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 65,
                  y: 150,
                  src: 'luk_L.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 74,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 4,
                  unit_sc: 'cyf_par_kardio.png',
                  unit_tc: 'cyf_par_kardio.png',
                  unit_en: 'cyf_par_kardio.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 65,
                  y: 150,
                  src: 'luk_L.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 64,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_10.png',
                  unit_tc: 'cyf_par_10.png',
                  unit_en: 'cyf_par_10.png',
                  dot_image: 'cyf_par_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 65,
                  y: 150,
                  src: 'luk_L.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 175,
              src: 'zn_error.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 284,
              y: 151,
              w: 130,
              h: 55,
              select_image: 'ram_SZB.png',
              un_select_image: 'ram_UZB.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(2)_BATTERY.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(2)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(2)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(2)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(2)_DISTANCE.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'X-X-X', title_tc: 'X-X-X', title_en: 'X-X-X' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
              ],
              count: 7,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: 'tooltip.png',
              tips_x: -7,
              tips_y: 61,
              tips_width: 154,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 290,
                  y: 150,
                  image_array: ["luk_P.png"],
                  image_length: 1,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 311,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_proc.png',
                  unit_tc: 'cyf_par_proc.png',
                  unit_en: 'cyf_par_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 368,
                  y: 173,
                  src: 'iko_AKU.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 303,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_but.png',
                  unit_tc: 'cyf_par_but.png',
                  unit_en: 'cyf_par_but.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 290,
                  y: 150,
                  src: 'luk_P.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 313,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_cal.png',
                  unit_tc: 'cyf_par_cal.png',
                  unit_en: 'cyf_par_cal.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 290,
                  y: 150,
                  src: 'luk_P.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 311,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 4,
                  unit_sc: 'cyf_par_kardio.png',
                  unit_tc: 'cyf_par_kardio.png',
                  unit_en: 'cyf_par_kardio.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 290,
                  y: 150,
                  src: 'luk_P.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 306,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 3,
                  unit_sc: 'cyf_par_10.png',
                  unit_tc: 'cyf_par_10.png',
                  unit_en: 'cyf_par_10.png',
                  dot_image: 'cyf_par_12.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 290,
                  y: 150,
                  src: 'luk_P.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 344,
              y: 150,
              src: 'zn_error.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 306,
                  y: 165,
                  image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 348,
                  y: 175,
                  font_array: ["cyf_par_00.png","cyf_par_01.png","cyf_par_02.png","cyf_par_03.png","cyf_par_04.png","cyf_par_05.png","cyf_par_06.png","cyf_par_07.png","cyf_par_08.png","cyf_par_09.png"],
                  padding: false,
                  h_space: 4,
                  unit_sc: 'cyf_par_13.png',
                  unit_tc: 'cyf_par_13.png',
                  unit_en: 'cyf_par_13.png',
                  negative_image: 'cyf_par_11.png',
                  invalid_image: 'zn_error.png',
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 290,
                  y: 150,
                  src: 'luk_P.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'transp454.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'par_Tm.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wsk_S1.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 22,
                    posY: 114,
                    path: 'wsk_H1.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 12,
                    posY: 180,
                    path: 'wsk_M1.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wsk_S2.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 22,
                    posY: 114,
                    path: 'wsk_H2.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 12,
                    posY: 180,
                    path: 'wsk_M2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: 'wsk_Hf.png',
              tips_x: 159,
              tips_y: 338,
              tips_bg: 'tooltip.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            editableTimePointers_cover_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'wsk_Fi.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 286,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 349,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 289,
              y: 286,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 346,
              y: 166,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 26,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 26,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 8,
              y: 166,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}